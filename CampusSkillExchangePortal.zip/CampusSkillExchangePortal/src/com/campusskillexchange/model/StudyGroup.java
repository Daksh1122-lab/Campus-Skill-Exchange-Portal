package com.campusskillexchange.model;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** A collaborative study group with a discussion board and a shared checklist of learning activities. */
public class StudyGroup implements Serializable {
    private static final long serialVersionUID = 1L;

    /** A discussion message or shared resource link. */
    public static class Post implements Serializable {
        private static final long serialVersionUID = 1L;
        private final int authorId;
        private final String text;
        private final LocalDateTime time = LocalDateTime.now();

        public Post(int authorId, String text) {
            this.authorId = authorId;
            this.text = text;
        }
        public int getAuthorId() { return authorId; }
        public String getText() { return text; }
        public LocalDateTime getTime() { return time; }
    }

    /** A shared learning task that any member can tick off. */
    public static class Activity implements Serializable {
        private static final long serialVersionUID = 1L;
        private final String title;
        private final int createdBy;
        private boolean done;
        private int completedBy;

        public Activity(String title, int createdBy) {
            this.title = title;
            this.createdBy = createdBy;
        }
        public String getTitle() { return title; }
        public int getCreatedBy() { return createdBy; }
        public boolean isDone() { return done; }
        public int getCompletedBy() { return completedBy; }
        public void markDone(int studentId) {
            this.done = true;
            this.completedBy = studentId;
        }
    }

    private final int id;
    private final String title;
    private final String topic;
    private final int maxMembers;
    private int ownerId;
    private final Set<Integer> members = new LinkedHashSet<>();
    private final List<Post> posts = new ArrayList<>();
    private final List<Activity> activities = new ArrayList<>();

    public StudyGroup(int id, String title, String topic, int ownerId, int maxMembers) {
        this.id = id;
        this.title = title;
        this.topic = topic;
        this.ownerId = ownerId;
        this.maxMembers = maxMembers;
        this.members.add(ownerId);
    }

    public int getId() { return id; }
    public String getTitle() { return title; }
    public String getTopic() { return topic; }
    public int getMaxMembers() { return maxMembers; }
    public int getOwnerId() { return ownerId; }
    public void setOwnerId(int ownerId) { this.ownerId = ownerId; }

    public Set<Integer> getMembers() { return Collections.unmodifiableSet(members); }
    public List<Post> getPosts() { return Collections.unmodifiableList(posts); }
    public List<Activity> getActivities() { return Collections.unmodifiableList(activities); }

    public boolean isMember(int studentId) { return members.contains(studentId); }
    public boolean isFull() { return members.size() >= maxMembers; }
    public void addMember(int studentId) { members.add(studentId); }
    public void removeMember(int studentId) { members.remove(studentId); }
    public void addPost(Post post) { posts.add(post); }
    public void addActivity(Activity activity) { activities.add(activity); }
}
