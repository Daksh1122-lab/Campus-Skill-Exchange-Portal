package com.campusskillexchange.model;

import java.io.Serializable;
import java.util.Collections;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

/** A student account: profile, skills they can teach, skills they want to learn, and mentor rating. */
public class Student implements Serializable {
    private static final long serialVersionUID = 1L;

    public enum Level { BEGINNER, INTERMEDIATE, ADVANCED }

    private final int id;
    private final String name;
    private final String email;
    private final String salt;
    private final String passwordHash;
    private final String department;
    private final int year;
    private final Map<String, Level> offeredSkills = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
    private final Set<String> wantedSkills = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
    private int ratingTotal;
    private int ratingCount;

    public Student(int id, String name, String email, String salt, String passwordHash,
                   String department, int year) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.salt = salt;
        this.passwordHash = passwordHash;
        this.department = department;
        this.year = year;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    public String getSalt() { return salt; }
    public String getPasswordHash() { return passwordHash; }
    public String getDepartment() { return department; }
    public int getYear() { return year; }
    public int getRatingCount() { return ratingCount; }

    public Map<String, Level> getOfferedSkills() { return Collections.unmodifiableMap(offeredSkills); }
    public Set<String> getWantedSkills() { return Collections.unmodifiableSet(wantedSkills); }

    public void offerSkill(String skill, Level level) { offeredSkills.put(skill, level); }
    public void wantSkill(String skill) { wantedSkills.add(skill); }

    /** Returns the stored spelling of a skill this student teaches (case-insensitive lookup). */
    public Optional<String> findOfferedSkill(String skill) {
        return offeredSkills.keySet().stream().filter(k -> k.equalsIgnoreCase(skill)).findFirst();
    }

    /** True if any taught skill contains the query, e.g. "java" matches "JavaScript". */
    public boolean offersSkillLike(String query) {
        String q = query.toLowerCase();
        return offeredSkills.keySet().stream().anyMatch(k -> k.toLowerCase().contains(q));
    }

    public void addRating(int stars) {
        ratingTotal += stars;
        ratingCount++;
    }

    public double averageRating() {
        return ratingCount == 0 ? 0 : (double) ratingTotal / ratingCount;
    }
}
