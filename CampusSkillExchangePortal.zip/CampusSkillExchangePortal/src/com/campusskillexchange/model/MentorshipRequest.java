package com.campusskillexchange.model;

import java.io.Serializable;
import java.time.LocalDateTime;

/** A request from a mentee asking a peer to mentor them in one skill. */
public class MentorshipRequest implements Serializable {
    private static final long serialVersionUID = 1L;

    public enum Status { PENDING, ACCEPTED, REJECTED, COMPLETED }

    private final int id;
    private final int menteeId;
    private final int mentorId;
    private final String skill;
    private final String message;
    private final LocalDateTime createdAt = LocalDateTime.now();
    private Status status = Status.PENDING;
    private int rating;
    private String feedback = "";

    public MentorshipRequest(int id, int menteeId, int mentorId, String skill, String message) {
        this.id = id;
        this.menteeId = menteeId;
        this.mentorId = mentorId;
        this.skill = skill;
        this.message = message;
    }

    public int getId() { return id; }
    public int getMenteeId() { return menteeId; }
    public int getMentorId() { return mentorId; }
    public String getSkill() { return skill; }
    public String getMessage() { return message; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public Status getStatus() { return status; }
    public int getRating() { return rating; }
    public String getFeedback() { return feedback; }

    public void setStatus(Status status) { this.status = status; }

    public void complete(int rating, String feedback) {
        this.rating = rating;
        this.feedback = feedback == null ? "" : feedback;
        this.status = Status.COMPLETED;
    }
}
