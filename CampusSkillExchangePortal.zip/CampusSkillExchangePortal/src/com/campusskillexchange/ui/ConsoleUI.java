package com.campusskillexchange.ui;

import com.campusskillexchange.model.MentorshipRequest;
import com.campusskillexchange.model.MentorshipRequest.Status;
import com.campusskillexchange.model.Student;
import com.campusskillexchange.model.Student.Level;
import com.campusskillexchange.model.StudyGroup;
import com.campusskillexchange.service.MentorshipService;
import com.campusskillexchange.service.PortalException;
import com.campusskillexchange.service.StudentService;
import com.campusskillexchange.service.StudyGroupService;
import com.campusskillexchange.storage.DataStore;

import java.nio.file.Path;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Scanner;
import java.util.stream.Collectors;

/** Menu-driven console front end. All rules live in the service layer; this class only reads and prints. */
public class ConsoleUI {
    private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("dd MMM, HH:mm");

    private final Scanner in = new Scanner(System.in);
    private final DataStore store;
    private final Path dataFile;
    private final StudentService students;
    private final MentorshipService mentorships;
    private final StudyGroupService groups;
    private Student current;

    public ConsoleUI(DataStore store, Path dataFile, StudentService students,
                     MentorshipService mentorships, StudyGroupService groups) {
        this.store = store;
        this.dataFile = dataFile;
        this.students = students;
        this.mentorships = mentorships;
        this.groups = groups;
    }

    public void run() {
        System.out.println("==========================================");
        System.out.println("      CAMPUS SKILL EXCHANGE PORTAL");
        System.out.println("  Share skills. Mentor peers. Learn together.");
        System.out.println("==========================================");
        try {
            boolean keepGoing = true;
            while (keepGoing) {
                try {
                    keepGoing = (current == null) ? guestMenu() : dashboard();
                } catch (PortalException e) {
                    System.out.println("! " + e.getMessage());
                }
                store.save(dataFile);
            }
        } catch (NoSuchElementException e) {
            store.save(dataFile); // input stream closed
        }
        System.out.println("Goodbye!");
    }

    // ---------- menus ----------

    private boolean guestMenu() {
        System.out.println("\n1. Register\n2. Login\n0. Exit");
        switch (ask("Choose")) {
            case "1": register(); return true;
            case "2": login(); return true;
            case "0": return false;
            default: System.out.println("Invalid choice."); return true;
        }
    }

    private boolean dashboard() {
        System.out.println("\n--- Dashboard: " + current.getName() + " ---");
        System.out.println("1. My profile");
        System.out.println("2. Add a skill I can teach");
        System.out.println("3. Add a skill I want to learn");
        System.out.println("4. Find mentors by skill");
        System.out.println("5. Suggested mentors for skills I want");
        System.out.println("6. Request mentorship");
        System.out.println("7. Incoming mentorship requests");
        System.out.println("8. My mentorship requests (complete & rate)");
        System.out.println("9. Study groups");
        System.out.println("0. Logout");
        switch (ask("Choose")) {
            case "1": showProfile(); break;
            case "2": students.offerSkill(current, ask("Skill you can teach (e.g. Java, Git)"), askLevel());
                      System.out.println("Skill added."); break;
            case "3": students.wantSkill(current, ask("Skill you want to learn"));
                      System.out.println("Skill added to your learning list."); break;
            case "4": findMentors(); break;
            case "5": suggestMentors(); break;
            case "6": requestMentorship(); break;
            case "7": incomingRequests(); break;
            case "8": myRequests(); break;
            case "9": groupMenu(); break;
            case "0": current = null; System.out.println("Logged out."); break;
            default: System.out.println("Invalid choice.");
        }
        return true;
    }

    // ---------- accounts & skills ----------

    private void register() {
        String name = ask("Full name");
        String email = ask("Email");
        String password = ask("Password (min 6 characters)");
        String dept = ask("Department");
        int year = askInt("Year of study (1-5)");
        current = students.register(name, email, password, dept, year);
        System.out.println("Welcome, " + current.getName() + "! Your student ID is " + current.getId() + ".");
    }

    private void login() {
        String email = ask("Email");
        String password = ask("Password");
        current = students.login(email, password);
        System.out.println("Welcome back, " + current.getName() + "!");
    }

    private void showProfile() {
        System.out.printf("%nName: %s (ID %d)%nEmail: %s%nDepartment: %s, Year %d%n",
                current.getName(), current.getId(), current.getEmail(), current.getDepartment(), current.getYear());
        System.out.println("Can teach: " + skillsText(current));
        System.out.println("Wants to learn: "
                + (current.getWantedSkills().isEmpty() ? "-" : String.join(", ", current.getWantedSkills())));
        System.out.println("Mentor rating: " + ratingText(current));
    }

    private void findMentors() {
        String skill = ask("Skill to search for");
        List<Student> list = students.findMentors(skill, current);
        if (list.isEmpty()) {
            System.out.println("No mentors found for \"" + skill + "\" yet.");
        } else {
            printMentors(list);
        }
    }

    private void suggestMentors() {
        if (current.getWantedSkills().isEmpty()) {
            System.out.println("Add skills you want to learn first (option 3).");
            return;
        }
        for (Map.Entry<String, List<Student>> e : students.suggestMentors(current).entrySet()) {
            System.out.println("\nFor " + e.getKey() + ":");
            if (e.getValue().isEmpty()) System.out.println("  (no mentors available yet)");
            else printMentors(e.getValue());
        }
    }

    // ---------- mentorship ----------

    private void requestMentorship() {
        int mentorId = askInt("Mentor's student ID");
        String skill = ask("Skill you want help with");
        String message = ask("Short message to the mentor");
        MentorshipRequest r = mentorships.request(current, mentorId, skill, message);
        System.out.println("Request #" + r.getId() + " sent to " + students.nameOf(mentorId) + ".");
    }

    private void incomingRequests() {
        List<MentorshipRequest> list = mentorships.incoming(current);
        if (list.isEmpty()) {
            System.out.println("No one has requested your mentorship yet.");
            return;
        }
        list.forEach(this::printRequest);
        if (list.stream().noneMatch(r -> r.getStatus() == Status.PENDING)) return;
        int id = askInt("Request ID to answer (0 to skip)");
        if (id == 0) return;
        boolean accept = ask("Accept? (y/n)").equalsIgnoreCase("y");
        mentorships.respond(current, id, accept);
        System.out.println(accept ? "Request accepted." : "Request declined.");
    }

    private void myRequests() {
        List<MentorshipRequest> list = mentorships.outgoing(current);
        if (list.isEmpty()) {
            System.out.println("You have not requested any mentorship yet.");
            return;
        }
        list.forEach(this::printRequest);
        int id = askInt("ID of an accepted session to mark completed (0 to skip)");
        if (id == 0) return;
        int rating = askInt("Rate your mentor (1-5)");
        String feedback = ask("Feedback (optional)");
        mentorships.complete(current, id, rating, feedback);
        System.out.println("Thanks! Session completed and mentor rated.");
    }

    // ---------- study groups ----------

    private void groupMenu() {
        while (true) {
            System.out.println("\n--- Study Groups ---");
            System.out.println("1. Browse / search groups\n2. Create a group\n3. Join a group");
            System.out.println("4. My groups\n5. Open a group (discussion & activities)\n6. Leave a group\n0. Back");
            try {
                switch (ask("Choose")) {
                    case "1": printGroups(groups.search(ask("Keyword (blank = all)"))); break;
                    case "2":
                        StudyGroup g = groups.create(current, ask("Group title"), ask("Topic"), askInt("Max members"));
                        System.out.println("Group created with ID " + g.getId() + ".");
                        break;
                    case "3": groups.join(current, askInt("Group ID")); System.out.println("Joined!"); break;
                    case "4": printGroups(groups.groupsOf(current)); break;
                    case "5": openGroup(); break;
                    case "6": groups.leave(current, askInt("Group ID")); System.out.println("You left the group."); break;
                    case "0": return;
                    default: System.out.println("Invalid choice.");
                }
            } catch (PortalException e) {
                System.out.println("! " + e.getMessage());
            }
            store.save(dataFile);
        }
    }

    private void openGroup() {
        int id = askInt("Group ID");
        groups.getForMember(current, id);
        while (true) {
            printGroup(groups.getForMember(current, id));
            System.out.println("1. Post to discussion\n2. Add a learning activity\n3. Mark an activity done\n0. Back");
            try {
                switch (ask("Choose")) {
                    case "1": groups.post(current, id, ask("Message or resource link")); break;
                    case "2": groups.addActivity(current, id, ask("Activity (e.g. Solve 5 DSA problems)")); break;
                    case "3": groups.completeActivity(current, id, askInt("Activity number")); break;
                    case "0": return;
                    default: System.out.println("Invalid choice.");
                }
            } catch (PortalException e) {
                System.out.println("! " + e.getMessage());
            }
            store.save(dataFile);
        }
    }

    // ---------- printing helpers ----------

    private void printMentors(List<Student> list) {
        for (Student s : list) {
            System.out.printf("  [ID %d] %s | %s, Year %d | rating: %s | teaches: %s%n",
                    s.getId(), s.getName(), s.getDepartment(), s.getYear(), ratingText(s), skillsText(s));
        }
    }

    private void printRequest(MentorshipRequest r) {
        String extra = r.getStatus() == Status.COMPLETED ? " | rated " + r.getRating() + "/5" : "";
        System.out.printf("  #%d | %s | %s -> %s | %s%s | \"%s\"%n", r.getId(), r.getSkill(),
                students.nameOf(r.getMenteeId()), students.nameOf(r.getMentorId()), r.getStatus(), extra, r.getMessage());
    }

    private void printGroups(List<StudyGroup> list) {
        if (list.isEmpty()) {
            System.out.println("No study groups found.");
            return;
        }
        for (StudyGroup g : list) {
            System.out.printf("  [ID %d] %s | topic: %s | %d/%d members | owner: %s%n", g.getId(), g.getTitle(),
                    g.getTopic(), g.getMembers().size(), g.getMaxMembers(), students.nameOf(g.getOwnerId()));
        }
    }

    private void printGroup(StudyGroup g) {
        System.out.printf("%n=== %s [%s] (ID %d) ===%n", g.getTitle(), g.getTopic(), g.getId());
        System.out.println("Members: " + g.getMembers().stream().map(students::nameOf).collect(Collectors.joining(", ")));
        System.out.println("Discussion:");
        if (g.getPosts().isEmpty()) System.out.println("  (no messages yet)");
        int from = Math.max(0, g.getPosts().size() - 10);
        for (StudyGroup.Post p : g.getPosts().subList(from, g.getPosts().size())) {
            System.out.printf("  [%s] %s: %s%n", p.getTime().format(TIME), students.nameOf(p.getAuthorId()), p.getText());
        }
        System.out.println("Learning activities:");
        if (g.getActivities().isEmpty()) System.out.println("  (none yet)");
        int n = 1;
        for (StudyGroup.Activity a : g.getActivities()) {
            System.out.printf("  %d. [%s] %s%s%n", n++, a.isDone() ? "x" : " ", a.getTitle(),
                    a.isDone() ? " (done by " + students.nameOf(a.getCompletedBy()) + ")" : "");
        }
    }

    private String skillsText(Student s) {
        if (s.getOfferedSkills().isEmpty()) return "-";
        return s.getOfferedSkills().entrySet().stream()
                .map(e -> e.getKey() + " (" + e.getValue() + ")").collect(Collectors.joining(", "));
    }

    private String ratingText(Student s) {
        return s.getRatingCount() == 0 ? "not rated yet"
                : String.format("%.1f/5 from %d review(s)", s.averageRating(), s.getRatingCount());
    }

    // ---------- input helpers ----------

    private String ask(String label) {
        System.out.print(label + ": ");
        return in.nextLine().trim();
    }

    private int askInt(String label) {
        try {
            return Integer.parseInt(ask(label));
        } catch (NumberFormatException e) {
            throw new PortalException("Please enter a valid number.");
        }
    }

    private Level askLevel() {
        switch (ask("Your level (1=Beginner, 2=Intermediate, 3=Advanced)")) {
            case "1": return Level.BEGINNER;
            case "2": return Level.INTERMEDIATE;
            case "3": return Level.ADVANCED;
            default: throw new PortalException("Please choose 1, 2 or 3.");
        }
    }
}
