package com.campusskillexchange.storage;

import com.campusskillexchange.model.MentorshipRequest;
import com.campusskillexchange.model.Student;
import com.campusskillexchange.model.StudyGroup;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;

/** In-memory data for the whole portal, persisted to a single file with Java serialization. */
public class DataStore implements Serializable {
    private static final long serialVersionUID = 1L;

    private final Map<Integer, Student> students = new LinkedHashMap<>();
    private final Map<Integer, MentorshipRequest> requests = new LinkedHashMap<>();
    private final Map<Integer, StudyGroup> groups = new LinkedHashMap<>();
    private int nextId = 1;

    public int nextId() { return nextId++; }
    public Map<Integer, Student> students() { return students; }
    public Map<Integer, MentorshipRequest> requests() { return requests; }
    public Map<Integer, StudyGroup> groups() { return groups; }

    public static DataStore load(Path file) {
        if (!Files.exists(file)) {
            return new DataStore();
        }
        try (ObjectInputStream in = new ObjectInputStream(new BufferedInputStream(Files.newInputStream(file)))) {
            return (DataStore) in.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Warning: could not read saved data (" + e.getMessage() + "). Starting fresh.");
            return new DataStore();
        }
    }

    public void save(Path file) {
        try {
            Path parent = file.getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }
            try (ObjectOutputStream out = new ObjectOutputStream(new BufferedOutputStream(Files.newOutputStream(file)))) {
                out.writeObject(this);
            }
        } catch (IOException e) {
            System.out.println("Warning: could not save data: " + e.getMessage());
        }
    }
}
