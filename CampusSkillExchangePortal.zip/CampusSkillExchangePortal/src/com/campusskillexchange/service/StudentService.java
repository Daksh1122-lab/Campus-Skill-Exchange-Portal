package com.campusskillexchange.service;

import com.campusskillexchange.model.Student;
import com.campusskillexchange.model.Student.Level;
import com.campusskillexchange.storage.DataStore;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/** Accounts, skill profiles, and mentor discovery. */
public class StudentService {
    private static final Pattern EMAIL = Pattern.compile("^[\\w.+-]+@[\\w-]+(\\.[\\w-]+)+$");
    private static final SecureRandom RANDOM = new SecureRandom();

    private final DataStore store;

    public StudentService(DataStore store) {
        this.store = store;
    }

    public Student register(String name, String email, String password, String department, int year) {
        if (name == null || name.isBlank()) throw new PortalException("Name is required.");
        if (email == null || !EMAIL.matcher(email.trim()).matches()) throw new PortalException("Enter a valid email address.");
        if (password == null || password.length() < 6) throw new PortalException("Password must be at least 6 characters.");
        if (department == null || department.isBlank()) throw new PortalException("Department is required.");
        if (year < 1 || year > 5) throw new PortalException("Year of study must be between 1 and 5.");
        if (findByEmail(email).isPresent()) throw new PortalException("An account with this email already exists.");

        byte[] saltBytes = new byte[16];
        RANDOM.nextBytes(saltBytes);
        String salt = Base64.getEncoder().encodeToString(saltBytes);
        Student student = new Student(store.nextId(), name.trim(), email.trim().toLowerCase(),
                salt, hash(salt, password), department.trim(), year);
        store.students().put(student.getId(), student);
        return student;
    }

    public Student login(String email, String password) {
        Student s = findByEmail(email).orElseThrow(() -> new PortalException("Invalid email or password."));
        byte[] expected = s.getPasswordHash().getBytes(StandardCharsets.UTF_8);
        byte[] actual = hash(s.getSalt(), password).getBytes(StandardCharsets.UTF_8);
        if (!MessageDigest.isEqual(expected, actual)) throw new PortalException("Invalid email or password.");
        return s;
    }

    public void offerSkill(Student student, String skill, Level level) {
        student.offerSkill(cleanSkill(skill), level);
    }

    public void wantSkill(Student student, String skill) {
        student.wantSkill(cleanSkill(skill));
    }

    /** Students (other than the requester) who teach a skill matching the query, best rated first. */
    public List<Student> findMentors(String skill, Student requester) {
        String query = cleanSkill(skill);
        return store.students().values().stream()
                .filter(s -> s.getId() != requester.getId())
                .filter(s -> s.offersSkillLike(query))
                .sorted(Comparator.comparingDouble(Student::averageRating).reversed()
                        .thenComparing(Student::getName))
                .collect(Collectors.toList());
    }

    /** For every skill the student wants to learn, the peers who can teach it. */
    public Map<String, List<Student>> suggestMentors(Student student) {
        Map<String, List<Student>> result = new LinkedHashMap<>();
        for (String wanted : student.getWantedSkills()) {
            result.put(wanted, findMentors(wanted, student));
        }
        return result;
    }

    public String nameOf(int studentId) {
        Student s = store.students().get(studentId);
        return s == null ? "Unknown" : s.getName();
    }

    private Optional<Student> findByEmail(String email) {
        if (email == null) return Optional.empty();
        String e = email.trim();
        return store.students().values().stream().filter(s -> s.getEmail().equalsIgnoreCase(e)).findFirst();
    }

    private static String cleanSkill(String skill) {
        if (skill == null || skill.isBlank()) throw new PortalException("Skill name cannot be empty.");
        String s = skill.trim();
        if (s.length() > 40) throw new PortalException("Skill name is too long (max 40 characters).");
        return s;
    }

    // Demo-grade hashing. For a production system use BCrypt/PBKDF2/Argon2 instead.
    private static String hash(String salt, String password) {
        try {
            byte[] digest = MessageDigest.getInstance("SHA-256")
                    .digest((salt + password).getBytes(StandardCharsets.UTF_8));
            return Base64.getEncoder().encodeToString(digest);
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }
}
