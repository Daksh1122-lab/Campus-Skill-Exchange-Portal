package com.campusskillexchange.service;

/** Thrown when a user action breaks a business rule (bad input, duplicate, not allowed...). */
public class PortalException extends RuntimeException {
    private static final long serialVersionUID = 1L;

    public PortalException(String message) {
        super(message);
    }
}
