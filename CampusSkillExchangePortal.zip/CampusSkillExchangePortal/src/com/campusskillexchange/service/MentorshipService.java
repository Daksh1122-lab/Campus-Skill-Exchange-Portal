package com.campusskillexchange.service;

import com.campusskillexchange.model.MentorshipRequest;
import com.campusskillexchange.model.MentorshipRequest.Status;
import com.campusskillexchange.model.Student;
import com.campusskillexchange.storage.DataStore;

import java.util.List;
import java.util.stream.Collectors;

/** Mentorship workflow: request -> accept/reject -> complete & rate. */
public class MentorshipService {
    private final DataStore store;

    public MentorshipService(DataStore store) {
        this.store = store;
    }

    public MentorshipRequest request(Student mentee, int mentorId, String skill, String message) {
        Student mentor = store.students().get(mentorId);
        if (mentor == null) throw new PortalException("No student found with ID " + mentorId + ".");
        if (mentor.getId() == mentee.getId()) throw new PortalException("You cannot request mentorship from yourself.");
        if (skill == null || skill.isBlank()) throw new PortalException("Skill name cannot be empty.");
        String taught = mentor.findOfferedSkill(skill.trim()).orElseThrow(
                () -> new PortalException(mentor.getName() + " does not teach \"" + skill.trim() + "\"."));

        boolean duplicate = store.requests().values().stream().anyMatch(r ->
                r.getMenteeId() == mentee.getId() && r.getMentorId() == mentorId
                        && r.getSkill().equalsIgnoreCase(taught)
                        && (r.getStatus() == Status.PENDING || r.getStatus() == Status.ACCEPTED));
        if (duplicate) throw new PortalException("You already have an open request with this mentor for " + taught + ".");

        MentorshipRequest req = new MentorshipRequest(store.nextId(), mentee.getId(), mentorId, taught,
                message == null ? "" : message.trim());
        store.requests().put(req.getId(), req);
        return req;
    }

    public void respond(Student mentor, int requestId, boolean accept) {
        MentorshipRequest r = find(requestId);
        if (r.getMentorId() != mentor.getId()) throw new PortalException("This request was not sent to you.");
        if (r.getStatus() != Status.PENDING) throw new PortalException("This request has already been answered.");
        r.setStatus(accept ? Status.ACCEPTED : Status.REJECTED);
    }

    public void complete(Student mentee, int requestId, int rating, String feedback) {
        MentorshipRequest r = find(requestId);
        if (r.getMenteeId() != mentee.getId()) throw new PortalException("This is not your request.");
        if (r.getStatus() != Status.ACCEPTED) throw new PortalException("Only accepted sessions can be completed.");
        if (rating < 1 || rating > 5) throw new PortalException("Rating must be between 1 and 5.");
        r.complete(rating, feedback);
        store.students().get(r.getMentorId()).addRating(rating);
    }

    public List<MentorshipRequest> incoming(Student mentor) {
        return store.requests().values().stream()
                .filter(r -> r.getMentorId() == mentor.getId()).collect(Collectors.toList());
    }

    public List<MentorshipRequest> outgoing(Student mentee) {
        return store.requests().values().stream()
                .filter(r -> r.getMenteeId() == mentee.getId()).collect(Collectors.toList());
    }

    private MentorshipRequest find(int id) {
        MentorshipRequest r = store.requests().get(id);
        if (r == null) throw new PortalException("No request found with ID " + id + ".");
        return r;
    }
}
