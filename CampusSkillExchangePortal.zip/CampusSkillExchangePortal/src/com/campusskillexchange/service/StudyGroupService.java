package com.campusskillexchange.service;

import com.campusskillexchange.model.Student;
import com.campusskillexchange.model.StudyGroup;
import com.campusskillexchange.model.StudyGroup.Activity;
import com.campusskillexchange.model.StudyGroup.Post;
import com.campusskillexchange.storage.DataStore;

import java.util.List;
import java.util.stream.Collectors;

/** Study groups: membership, discussion board, and shared learning activities. */
public class StudyGroupService {
    private final DataStore store;

    public StudyGroupService(DataStore store) {
        this.store = store;
    }

    public StudyGroup create(Student owner, String title, String topic, int maxMembers) {
        if (title == null || title.isBlank()) throw new PortalException("Group title is required.");
        if (topic == null || topic.isBlank()) throw new PortalException("Group topic is required.");
        if (maxMembers < 2 || maxMembers > 50) throw new PortalException("Group size must be between 2 and 50.");
        StudyGroup g = new StudyGroup(store.nextId(), title.trim(), topic.trim(), owner.getId(), maxMembers);
        store.groups().put(g.getId(), g);
        return g;
    }

    public void join(Student s, int groupId) {
        StudyGroup g = get(groupId);
        if (g.isMember(s.getId())) throw new PortalException("You are already a member of this group.");
        if (g.isFull()) throw new PortalException("This group is full.");
        g.addMember(s.getId());
    }

    public void leave(Student s, int groupId) {
        StudyGroup g = getForMember(s, groupId);
        g.removeMember(s.getId());
        if (g.getMembers().isEmpty()) {
            store.groups().remove(groupId);
        } else if (g.getOwnerId() == s.getId()) {
            g.setOwnerId(g.getMembers().iterator().next());
        }
    }

    public void post(Student s, int groupId, String text) {
        StudyGroup g = getForMember(s, groupId);
        if (text == null || text.isBlank()) throw new PortalException("Message cannot be empty.");
        g.addPost(new Post(s.getId(), text.trim()));
    }

    public void addActivity(Student s, int groupId, String title) {
        StudyGroup g = getForMember(s, groupId);
        if (title == null || title.isBlank()) throw new PortalException("Activity title cannot be empty.");
        g.addActivity(new Activity(title.trim(), s.getId()));
    }

    /** number is 1-based, as shown in the activity list. */
    public void completeActivity(Student s, int groupId, int number) {
        StudyGroup g = getForMember(s, groupId);
        if (number < 1 || number > g.getActivities().size()) throw new PortalException("No activity with that number.");
        Activity a = g.getActivities().get(number - 1);
        if (a.isDone()) throw new PortalException("That activity is already done.");
        a.markDone(s.getId());
    }

    /** Empty keyword returns every group. */
    public List<StudyGroup> search(String keyword) {
        String k = keyword == null ? "" : keyword.trim().toLowerCase();
        return store.groups().values().stream()
                .filter(g -> k.isEmpty() || g.getTitle().toLowerCase().contains(k) || g.getTopic().toLowerCase().contains(k))
                .collect(Collectors.toList());
    }

    public List<StudyGroup> groupsOf(Student s) {
        return store.groups().values().stream().filter(g -> g.isMember(s.getId())).collect(Collectors.toList());
    }

    public StudyGroup get(int groupId) {
        StudyGroup g = store.groups().get(groupId);
        if (g == null) throw new PortalException("No group found with ID " + groupId + ".");
        return g;
    }

    public StudyGroup getForMember(Student s, int groupId) {
        StudyGroup g = get(groupId);
        if (!g.isMember(s.getId())) throw new PortalException("Join the group first to do that.");
        return g;
    }
}
