package com.campusskillexchange;

import com.campusskillexchange.model.Student;
import com.campusskillexchange.model.Student.Level;
import com.campusskillexchange.model.StudyGroup;
import com.campusskillexchange.service.MentorshipService;
import com.campusskillexchange.service.StudentService;
import com.campusskillexchange.service.StudyGroupService;

/** Sample accounts so the portal can be explored immediately (run with --demo). Password for all: pass1234 */
final class DemoData {
    private DemoData() { }

    static void seed(StudentService students, MentorshipService mentorships, StudyGroupService groups) {
        Student aarav = students.register("Aarav Sharma", "aarav@campus.edu", "pass1234", "CSE", 3);
        students.offerSkill(aarav, "Java", Level.ADVANCED);
        students.offerSkill(aarav, "Git", Level.INTERMEDIATE);
        students.wantSkill(aarav, "Machine Learning");

        Student meera = students.register("Meera Iyer", "meera@campus.edu", "pass1234", "AI & ML", 2);
        students.offerSkill(meera, "Python", Level.ADVANCED);
        students.offerSkill(meera, "Machine Learning", Level.INTERMEDIATE);
        students.wantSkill(meera, "Java");

        Student rohan = students.register("Rohan Gupta", "rohan@campus.edu", "pass1234", "ECE", 4);
        students.offerSkill(rohan, "Embedded C", Level.ADVANCED);
        students.offerSkill(rohan, "Arduino", Level.INTERMEDIATE);
        students.wantSkill(rohan, "Python");

        mentorships.request(meera, aarav.getId(), "Java", "Could you help me understand OOP and collections?");

        StudyGroup dsa = groups.create(aarav, "DSA Weekend Warriors", "Data Structures", 8);
        groups.join(meera, dsa.getId());
        groups.post(aarav, dsa.getId(), "Let's solve 5 recursion problems this Saturday.");
        groups.addActivity(aarav, dsa.getId(), "Solve 5 recursion problems");
    }
}
