package com.campusskillexchange;

import com.campusskillexchange.service.MentorshipService;
import com.campusskillexchange.service.StudentService;
import com.campusskillexchange.service.StudyGroupService;
import com.campusskillexchange.storage.DataStore;
import com.campusskillexchange.ui.ConsoleUI;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;

/** Entry point. Run with "--demo" to start with sample students, a request and a study group. */
public class Main {
    private static final Path DATA_FILE = Paths.get("data", "portal.dat");

    public static void main(String[] args) {
        DataStore store = DataStore.load(DATA_FILE);
        StudentService students = new StudentService(store);
        MentorshipService mentorships = new MentorshipService(store);
        StudyGroupService groups = new StudyGroupService(store);

        if (Arrays.asList(args).contains("--demo") && store.students().isEmpty()) {
            DemoData.seed(students, mentorships, groups);
            store.save(DATA_FILE);
            System.out.println("Demo data loaded. Log in as aarav@campus.edu / meera@campus.edu / rohan@campus.edu (password: pass1234).");
        }
        new ConsoleUI(store, DATA_FILE, students, mentorships, groups).run();
    }
}
