package com.campusskillexchange;

import com.campusskillexchange.model.MentorshipRequest;
import com.campusskillexchange.model.Student;
import com.campusskillexchange.model.Student.Level;
import com.campusskillexchange.model.StudyGroup;
import com.campusskillexchange.service.MentorshipService;
import com.campusskillexchange.service.PortalException;
import com.campusskillexchange.service.StudentService;
import com.campusskillexchange.service.StudyGroupService;
import com.campusskillexchange.storage.DataStore;

import java.nio.file.Files;
import java.nio.file.Path;

/** Dependency-free tests: run with  java -cp out com.campusskillexchange.PortalSmokeTest  */
public class PortalSmokeTest {
    private static int failed = 0;

    public static void main(String[] args) throws Exception {
        DataStore store = new DataStore();
        StudentService students = new StudentService(store);
        MentorshipService mentorships = new MentorshipService(store);
        StudyGroupService groups = new StudyGroupService(store);

        Student asha = students.register("Asha", "asha@campus.edu", "secret1", "CSE", 3);
        Student ben = students.register("Ben", "ben@campus.edu", "secret2", "ECE", 2);
        check("duplicate email rejected", fails(() -> students.register("X", "ASHA@campus.edu", "secret1", "CSE", 1)));
        check("weak password rejected", fails(() -> students.register("X", "x@campus.edu", "123", "CSE", 1)));
        check("login works", students.login("asha@campus.edu", "secret1").getId() == asha.getId());
        check("wrong password rejected", fails(() -> students.login("asha@campus.edu", "nope")));

        students.offerSkill(asha, "Java", Level.ADVANCED);
        students.wantSkill(ben, "java");
        check("mentor search is case-insensitive", students.findMentors("JAVA", ben).size() == 1);
        check("suggestions match wanted skills", students.suggestMentors(ben).get("java").get(0).getId() == asha.getId());

        MentorshipRequest r = mentorships.request(ben, asha.getId(), "java", "Help with OOP");
        check("duplicate open request rejected", fails(() -> mentorships.request(ben, asha.getId(), "Java", "again")));
        check("cannot complete before accept", fails(() -> mentorships.complete(ben, r.getId(), 5, "")));
        check("only the mentor can answer", fails(() -> mentorships.respond(ben, r.getId(), true)));
        mentorships.respond(asha, r.getId(), true);
        check("bad rating rejected", fails(() -> mentorships.complete(ben, r.getId(), 9, "")));
        mentorships.complete(ben, r.getId(), 5, "Great!");
        check("mentor rating updated", asha.averageRating() == 5.0 && asha.getRatingCount() == 1);

        StudyGroup g = groups.create(asha, "DSA Club", "Data Structures", 2);
        groups.join(ben, g.getId());
        check("full group rejects joins", fails(() -> groups.join(students.register("Cy", "cy@campus.edu", "secret3", "IT", 1), g.getId())));
        groups.post(ben, g.getId(), "Hello!");
        groups.addActivity(asha, g.getId(), "Solve 5 problems");
        groups.completeActivity(ben, g.getId(), 1);
        check("activity done", g.getActivities().get(0).isDone() && g.getPosts().size() == 1);
        groups.leave(asha, g.getId());
        check("ownership transferred on leave", g.getOwnerId() == ben.getId());

        Path tmp = Files.createTempFile("portal", ".dat");
        store.save(tmp);
        DataStore loaded = DataStore.load(tmp);
        check("data survives save/load", loaded.students().size() == 3 && loaded.groups().size() == 1
                && loaded.students().get(asha.getId()).getOfferedSkills().containsKey("java"));
        Files.deleteIfExists(tmp);

        System.out.println(failed == 0 ? "\nAll tests passed." : "\n" + failed + " test(s) FAILED.");
        System.exit(failed == 0 ? 0 : 1);
    }

    private static boolean fails(Runnable action) {
        try { action.run(); return false; } catch (PortalException e) { return true; }
    }

    private static void check(String name, boolean ok) {
        System.out.println((ok ? "PASS  " : "FAIL  ") + name);
        if (!ok) failed++;
    }
}
